package com.codewithkael.javawebrtcyoutube.utils;

public interface SuccessCallBack {
    void onSuccess();
}
