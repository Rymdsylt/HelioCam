package com.codewithkael.javawebrtcyoutube.utils;

public interface ErrorCallBack {
    void onError();
}
