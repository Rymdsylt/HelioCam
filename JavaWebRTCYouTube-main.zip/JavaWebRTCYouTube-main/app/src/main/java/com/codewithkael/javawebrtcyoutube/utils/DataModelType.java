package com.codewithkael.javawebrtcyoutube.utils;

public enum DataModelType {
    Offer, Answer, IceCandidate, StartCall
}
